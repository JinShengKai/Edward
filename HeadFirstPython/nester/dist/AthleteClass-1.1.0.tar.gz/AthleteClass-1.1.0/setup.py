from distutils.core import setup
setup(
    name    = 'AthleteClass',
    version = '1.1.0',
    py_modules =['Python_Class'],
    author='Edward',
    author_email='shengkaijin@hotmail.com',
    url='43',
    description='A simple printer of nested list',
)